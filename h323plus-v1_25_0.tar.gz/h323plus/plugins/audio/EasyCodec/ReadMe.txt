++++++++++++++++++++++++++++++++++++++++++++++
Instructions on compiling the Easy Codecs
++++++++++++++++++++++++++++++++++++++++++++++

Warning: 
These Codecs (except G7231) have frame rates of 
10ms For proper audio make sure the sound buffer 
size in your Application is set to a minimum of 5
otherwise you will have poor audio.

1. Download the codec files from www.ImTelephone.com and install them in the following subdirectories.
	Easy/EasyG722
	Easy/EasyG7231
	Easy/EasyG728
	Easy/EasyG729A

2. Open EasyCodecs.dsw select batch build and build the appropriate plugins.

	